c = get_config()

c.Exporter.template_file = 'jupyter_template'
